﻿namespace AKotschevar1F1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.picRomaniaDIM = new System.Windows.Forms.PictureBox();
            this.picRomania = new System.Windows.Forms.PictureBox();
            this.picUK = new System.Windows.Forms.PictureBox();
            this.picZimbabwe = new System.Windows.Forms.PictureBox();
            this.picAngola = new System.Windows.Forms.PictureBox();
            this.picUKDIM = new System.Windows.Forms.PictureBox();
            this.picAngolaDIM = new System.Windows.Forms.PictureBox();
            this.picZimbabweDIM = new System.Windows.Forms.PictureBox();
            this.btnRomania = new System.Windows.Forms.Button();
            this.btnUK = new System.Windows.Forms.Button();
            this.btnAngola = new System.Windows.Forms.Button();
            this.btnZimbabwe = new System.Windows.Forms.Button();
            this.btnRate = new System.Windows.Forms.Label();
            this.btnRomUS = new System.Windows.Forms.Label();
            this.txtCurrency = new System.Windows.Forms.TextBox();
            this.txtRate = new System.Windows.Forms.TextBox();
            this.txtTotalUSD = new System.Windows.Forms.TextBox();
            this.txtUSDollars = new System.Windows.Forms.TextBox();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.lblEquation = new System.Windows.Forms.Label();
            this.labelEquation = new System.Windows.Forms.Label();
            this.lblCurrency = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picRomaniaDIM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRomania)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picUK)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picZimbabwe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAngola)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picUKDIM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAngolaDIM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picZimbabweDIM)).BeginInit();
            this.SuspendLayout();
            // 
            // picRomaniaDIM
            // 
            this.picRomaniaDIM.Image = global::AKotschevar1F1.Properties.Resources.Romanian_Flag_dim;
            this.picRomaniaDIM.Location = new System.Drawing.Point(504, 405);
            this.picRomaniaDIM.Name = "picRomaniaDIM";
            this.picRomaniaDIM.Size = new System.Drawing.Size(133, 136);
            this.picRomaniaDIM.TabIndex = 1;
            this.picRomaniaDIM.TabStop = false;
            this.picRomaniaDIM.Visible = false;
            // 
            // picRomania
            // 
            this.picRomania.Image = global::AKotschevar1F1.Properties.Resources.Romanian_Flag;
            this.picRomania.Location = new System.Drawing.Point(6, 498);
            this.picRomania.Name = "picRomania";
            this.picRomania.Size = new System.Drawing.Size(133, 136);
            this.picRomania.TabIndex = 0;
            this.picRomania.TabStop = false;
            this.picRomania.Visible = false;
            // 
            // picUK
            // 
            this.picUK.Image = ((System.Drawing.Image)(resources.GetObject("picUK.Image")));
            this.picUK.Location = new System.Drawing.Point(160, 504);
            this.picUK.Name = "picUK";
            this.picUK.Size = new System.Drawing.Size(142, 122);
            this.picUK.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picUK.TabIndex = 2;
            this.picUK.TabStop = false;
            this.picUK.Visible = false;
            // 
            // picZimbabwe
            // 
            this.picZimbabwe.Image = ((System.Drawing.Image)(resources.GetObject("picZimbabwe.Image")));
            this.picZimbabwe.Location = new System.Drawing.Point(475, 552);
            this.picZimbabwe.Name = "picZimbabwe";
            this.picZimbabwe.Size = new System.Drawing.Size(149, 122);
            this.picZimbabwe.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picZimbabwe.TabIndex = 3;
            this.picZimbabwe.TabStop = false;
            this.picZimbabwe.Visible = false;
            // 
            // picAngola
            // 
            this.picAngola.Image = ((System.Drawing.Image)(resources.GetObject("picAngola.Image")));
            this.picAngola.Location = new System.Drawing.Point(324, 512);
            this.picAngola.Name = "picAngola";
            this.picAngola.Size = new System.Drawing.Size(142, 122);
            this.picAngola.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picAngola.TabIndex = 4;
            this.picAngola.TabStop = false;
            this.picAngola.Visible = false;
            // 
            // picUKDIM
            // 
            this.picUKDIM.Image = ((System.Drawing.Image)(resources.GetObject("picUKDIM.Image")));
            this.picUKDIM.Location = new System.Drawing.Point(658, 405);
            this.picUKDIM.Name = "picUKDIM";
            this.picUKDIM.Size = new System.Drawing.Size(142, 122);
            this.picUKDIM.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picUKDIM.TabIndex = 5;
            this.picUKDIM.TabStop = false;
            this.picUKDIM.Visible = false;
            // 
            // picAngolaDIM
            // 
            this.picAngolaDIM.Image = ((System.Drawing.Image)(resources.GetObject("picAngolaDIM.Image")));
            this.picAngolaDIM.Location = new System.Drawing.Point(822, 412);
            this.picAngolaDIM.Name = "picAngolaDIM";
            this.picAngolaDIM.Size = new System.Drawing.Size(142, 122);
            this.picAngolaDIM.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picAngolaDIM.TabIndex = 6;
            this.picAngolaDIM.TabStop = false;
            this.picAngolaDIM.Visible = false;
            // 
            // picZimbabweDIM
            // 
            this.picZimbabweDIM.Image = ((System.Drawing.Image)(resources.GetObject("picZimbabweDIM.Image")));
            this.picZimbabweDIM.Location = new System.Drawing.Point(1027, 372);
            this.picZimbabweDIM.Name = "picZimbabweDIM";
            this.picZimbabweDIM.Size = new System.Drawing.Size(149, 122);
            this.picZimbabweDIM.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picZimbabweDIM.TabIndex = 7;
            this.picZimbabweDIM.TabStop = false;
            this.picZimbabweDIM.Visible = false;
            // 
            // btnRomania
            // 
            this.btnRomania.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnRomania.Font = new System.Drawing.Font("Rockwell", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRomania.Location = new System.Drawing.Point(50, 12);
            this.btnRomania.Name = "btnRomania";
            this.btnRomania.Size = new System.Drawing.Size(165, 162);
            this.btnRomania.TabIndex = 8;
            this.btnRomania.Text = "Romania Currency";
            this.btnRomania.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnRomania.UseVisualStyleBackColor = true;
            this.btnRomania.Click += new System.EventHandler(this.btnRomania_Click);
            // 
            // btnUK
            // 
            this.btnUK.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnUK.Font = new System.Drawing.Font("Rockwell", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUK.Location = new System.Drawing.Point(226, 12);
            this.btnUK.Name = "btnUK";
            this.btnUK.Size = new System.Drawing.Size(169, 162);
            this.btnUK.TabIndex = 9;
            this.btnUK.Text = "UK Currency";
            this.btnUK.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnUK.UseVisualStyleBackColor = true;
            this.btnUK.Click += new System.EventHandler(this.btnUK_Click);
            // 
            // btnAngola
            // 
            this.btnAngola.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAngola.Font = new System.Drawing.Font("Rockwell", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAngola.Location = new System.Drawing.Point(406, 12);
            this.btnAngola.Name = "btnAngola";
            this.btnAngola.Size = new System.Drawing.Size(169, 162);
            this.btnAngola.TabIndex = 10;
            this.btnAngola.Text = "Angola Currency";
            this.btnAngola.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAngola.UseVisualStyleBackColor = true;
            this.btnAngola.Click += new System.EventHandler(this.btnAngola_Click);
            // 
            // btnZimbabwe
            // 
            this.btnZimbabwe.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnZimbabwe.Font = new System.Drawing.Font("Rockwell", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnZimbabwe.Location = new System.Drawing.Point(590, 12);
            this.btnZimbabwe.Name = "btnZimbabwe";
            this.btnZimbabwe.Size = new System.Drawing.Size(169, 162);
            this.btnZimbabwe.TabIndex = 11;
            this.btnZimbabwe.Text = "Zimbabwe Currency";
            this.btnZimbabwe.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnZimbabwe.UseVisualStyleBackColor = true;
            this.btnZimbabwe.Click += new System.EventHandler(this.btnZimbabwe_Click);
            // 
            // btnRate
            // 
            this.btnRate.AutoSize = true;
            this.btnRate.Location = new System.Drawing.Point(66, 220);
            this.btnRate.Name = "btnRate";
            this.btnRate.Size = new System.Drawing.Size(42, 17);
            this.btnRate.TabIndex = 13;
            this.btnRate.Text = "Rate:";
            // 
            // btnRomUS
            // 
            this.btnRomUS.AutoSize = true;
            this.btnRomUS.Location = new System.Drawing.Point(66, 248);
            this.btnRomUS.Name = "btnRomUS";
            this.btnRomUS.Size = new System.Drawing.Size(35, 17);
            this.btnRomUS.TabIndex = 14;
            this.btnRomUS.Text = "$US";
            // 
            // txtCurrency
            // 
            this.txtCurrency.Location = new System.Drawing.Point(238, 187);
            this.txtCurrency.Name = "txtCurrency";
            this.txtCurrency.Size = new System.Drawing.Size(156, 22);
            this.txtCurrency.TabIndex = 15;
            this.txtCurrency.Text = "0.00";
            this.txtCurrency.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCurrency.Click += new System.EventHandler(this.btnRomania_Click);
            this.txtCurrency.TextChanged += new System.EventHandler(this.calcUSD);
            this.txtCurrency.Enter += new System.EventHandler(this.txtCurrency_Enter);
            // 
            // txtRate
            // 
            this.txtRate.Location = new System.Drawing.Point(238, 215);
            this.txtRate.Name = "txtRate";
            this.txtRate.Size = new System.Drawing.Size(156, 22);
            this.txtRate.TabIndex = 16;
            this.txtRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtRate.TextChanged += new System.EventHandler(this.calcUSD);
            // 
            // txtTotalUSD
            // 
            this.txtTotalUSD.Location = new System.Drawing.Point(238, 271);
            this.txtTotalUSD.Name = "txtTotalUSD";
            this.txtTotalUSD.ReadOnly = true;
            this.txtTotalUSD.Size = new System.Drawing.Size(156, 22);
            this.txtTotalUSD.TabIndex = 18;
            this.txtTotalUSD.TabStop = false;
            this.txtTotalUSD.Text = "0.00";
            this.txtTotalUSD.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTotalUSD.TextChanged += new System.EventHandler(this.txtTotalUSD_TextChanged);
            // 
            // txtUSDollars
            // 
            this.txtUSDollars.Location = new System.Drawing.Point(238, 243);
            this.txtUSDollars.Name = "txtUSDollars";
            this.txtUSDollars.ReadOnly = true;
            this.txtUSDollars.Size = new System.Drawing.Size(156, 22);
            this.txtUSDollars.TabIndex = 17;
            this.txtUSDollars.TabStop = false;
            this.txtUSDollars.Text = "0.00";
            this.txtUSDollars.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtUSDollars.TextChanged += new System.EventHandler(this.txtUSDollars_TextChanged);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(238, 304);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(156, 32);
            this.btnReset.TabIndex = 19;
            this.btnReset.Text = "R&eset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(400, 304);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(155, 32);
            this.btnExit.TabIndex = 20;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.Location = new System.Drawing.Point(416, 248);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(34, 32);
            this.btnAdd.TabIndex = 21;
            this.btnAdd.Text = "+";
            this.btnAdd.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblEquation
            // 
            this.lblEquation.AutoSize = true;
            this.lblEquation.Location = new System.Drawing.Point(108, 304);
            this.lblEquation.Name = "lblEquation";
            this.lblEquation.Size = new System.Drawing.Size(0, 17);
            this.lblEquation.TabIndex = 22;
            // 
            // labelEquation
            // 
            this.labelEquation.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.labelEquation.Location = new System.Drawing.Point(50, 271);
            this.labelEquation.Name = "labelEquation";
            this.labelEquation.Size = new System.Drawing.Size(169, 65);
            this.labelEquation.TabIndex = 24;
            this.labelEquation.Click += new System.EventHandler(this.labelEquation_Click);
            // 
            // lblCurrency
            // 
            this.lblCurrency.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.lblCurrency.Location = new System.Drawing.Point(50, 187);
            this.lblCurrency.Name = "lblCurrency";
            this.lblCurrency.Size = new System.Drawing.Size(169, 22);
            this.lblCurrency.TabIndex = 25;
            this.lblCurrency.Click += new System.EventHandler(this.lblCurrency_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(794, 382);
            this.Controls.Add(this.lblCurrency);
            this.Controls.Add(this.labelEquation);
            this.Controls.Add(this.lblEquation);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.txtTotalUSD);
            this.Controls.Add(this.txtUSDollars);
            this.Controls.Add(this.txtRate);
            this.Controls.Add(this.txtCurrency);
            this.Controls.Add(this.btnRomUS);
            this.Controls.Add(this.btnRate);
            this.Controls.Add(this.btnZimbabwe);
            this.Controls.Add(this.btnAngola);
            this.Controls.Add(this.btnUK);
            this.Controls.Add(this.btnRomania);
            this.Controls.Add(this.picZimbabweDIM);
            this.Controls.Add(this.picAngolaDIM);
            this.Controls.Add(this.picUKDIM);
            this.Controls.Add(this.picAngola);
            this.Controls.Add(this.picZimbabwe);
            this.Controls.Add(this.picUK);
            this.Controls.Add(this.picRomaniaDIM);
            this.Controls.Add(this.picRomania);
            this.Name = "Form1";
            this.Text = "AKotschevar F1 Currency Exchange";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picRomaniaDIM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRomania)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picUK)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picZimbabwe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAngola)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picUKDIM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAngolaDIM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picZimbabweDIM)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picRomania;
        private System.Windows.Forms.PictureBox picRomaniaDIM;
        private System.Windows.Forms.PictureBox picUK;
        private System.Windows.Forms.PictureBox picZimbabwe;
        private System.Windows.Forms.PictureBox picAngola;
        private System.Windows.Forms.PictureBox picUKDIM;
        private System.Windows.Forms.PictureBox picAngolaDIM;
        private System.Windows.Forms.PictureBox picZimbabweDIM;
        private System.Windows.Forms.Button btnRomania;
        private System.Windows.Forms.Button btnUK;
        private System.Windows.Forms.Button btnAngola;
        private System.Windows.Forms.Button btnZimbabwe;

        private System.Windows.Forms.Label btnRate;
        private System.Windows.Forms.Label btnRomUS;
        private System.Windows.Forms.TextBox txtCurrency;
        private System.Windows.Forms.TextBox txtRate;
        private System.Windows.Forms.TextBox txtTotalUSD;
        private System.Windows.Forms.TextBox txtUSDollars;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Label lblEquation;
        private System.Windows.Forms.Label labelEquation;
        private System.Windows.Forms.Label lblCurrency;
    }
}

